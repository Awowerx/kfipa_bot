package com.senderman.lastkatkabot

object Services {
    lateinit var handler: LastkatkaBotHandler
    lateinit var db: DBService
    lateinit var botConfig: BotConfig
}